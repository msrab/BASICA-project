<!--
    resources/views/home/admin/home.blade.php
    view du dashboard de l'administration
-->

@extends('layouts.admin')

@section('contenu')
@endsection
