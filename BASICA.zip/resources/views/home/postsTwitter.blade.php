<!--
    resources/views/home/postsTwitter.blade.php
    view des posts publiés sur Twitter
-->

<!-- Latest News FB -->
<div class="col-sm-6 latest-news">
    <h2>Lastest FaceBook/Twitter News</h2>
    <a class="twitter-timeline" data-width="580" data-height="357" data-dnt="true" data-theme="light" data-link-color="#aec62c" href="https://twitter.com/Twitter">Tweets by Twitter</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>
<!-- End Featured News -->