<!--
    resources/views/home/index.blade.php
    view de la page d'accueil
-->



<?php $__env->startSection('contenu'); ?>

<!-- SLIDER -->
<?php if(count($articles) > 0): ?>
<?php echo $__env->make('home.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>


<!-- PORTFOLIO -->
<?php if(count($works) > 0): ?>
<?php echo $__env->make('home.portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<hr>

<!-- Our Articles -->
<div class="section">
    <div class="container">
        <div class="row">

            <!-- LATEST POSTS -->
            <?php if(count($posts) > 0): ?>
            <?php echo $__env->make('home.latestPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

            <!-- POSTS TWITTER -->
            <?php echo $__env->make('home.postsTwitter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>