<?php $__env->startSection('contenu'); ?>
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Ajouter un article </h2>
        <?php echo e(Form::open(array('url'=>'admin/articles/store','enctype'=>'multipart/form-data'))); ?>

        <?php echo e(Form::token()); ?>


        <p>
            <?php echo e(Form::label('title','Titre')); ?>

            <?php echo e(Form::text('title', old('title'))); ?>

        </p>
        <?php if($errors->first('title')): ?>
        <span class="error"><?php echo e($errors->first('title')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('slug','Slug')); ?>

            <?php echo e(Form::text('slug', old('slug'))); ?>

        </p>
        <?php if($errors->first('slug')): ?>
        <span class="error"><?php echo e($errors->first('slug')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('subtitle','Sous-titre')); ?>

            <?php echo e(Form::text('subtitle', old('subtitle'))); ?>

        </p>
        <?php if($errors->first('subtitle')): ?>
        <span class="error"><?php echo e($errors->first('subtitle')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('text','Texte')); ?>

            <?php echo e(Form::textarea('text',old('text'))); ?>

        </p>
        <p>
            <?php echo e(Form::label('image','Image')); ?>

            <?php echo e(Form::file('image')); ?>

        </p>
        <?php if($errors->first('image')): ?>
        <span class="error"><?php echo e($errors->first('image')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('slide','Afficher dans le slider')); ?>

            <?php echo e(Form::checkbox('slide',old('slide'))); ?>

        </p>

        <p><?php echo e(Form::submit('Enregistrer')); ?></p>
        <?php echo e(Form::close()); ?>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>