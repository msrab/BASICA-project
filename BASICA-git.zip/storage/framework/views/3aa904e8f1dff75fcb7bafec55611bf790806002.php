<!--
    resources/views/home/latestPosts.blade.php
    view de la liste des posts récents
-->

<!-- Featured News -->
<div class="col-sm-6 featured-news">
    <h2>Latest Blog Posts</h2>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-xs-4"><a href="<?php echo e(URL::to('posts/'.$post->slug)); ?>"><img src="<?php echo e(Request::root().'/'.$post->image); ?>" alt="<?php echo e($post->title); ?>"></a></div>
        <div class="col-xs-8">
            <div class="caption"><a href="<?php echo e(URL::to('posts/'.$post->slug)); ?>"><?php echo e($post->title); ?></a></div>
            <div class="date"><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d M Y')); ?> </div>
            <div class="intro"><?php echo e(Str::words($post->text,17)); ?> <a href="<?php echo e(URL::to('posts/'.$post->slug)); ?>">Read more...</a></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- End Featured News -->