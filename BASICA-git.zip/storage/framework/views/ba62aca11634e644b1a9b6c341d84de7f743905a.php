<!--
    resources/views/posts/recentPosts.blade.php
    view de la liste des posts recents
-->

<h4>Recent Posts</h4>
<ul class="recent-posts">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(URL::to('posts/'.$post->slug)); ?>"><?php echo e($post->title); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>