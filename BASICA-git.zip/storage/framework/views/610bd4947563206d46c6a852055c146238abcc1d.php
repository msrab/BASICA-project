<!--
    resources/views/home/admin/home.blade.php
    view du dashboard de l'administration
-->



<?php $__env->startSection('contenu'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>