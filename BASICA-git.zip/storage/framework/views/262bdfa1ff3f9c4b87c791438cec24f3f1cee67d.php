<!--
    resources/views/tags/admin/liste.blade.php
    view de la liste des tags
-->



<?php $__env->startSection('contenu'); ?>
<!-- PAGE -->
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Les tags </h2>
        <p><?php echo e(Html::link('admin/tags/create', 'Ajouter un tag')); ?></p>
        <table>
            <thead>
                <tr>
                    <td>Tags</td>
                    <td class='actions'></td>
                    <td class='actions'></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tag->name); ?></td>
                    <td>
                        <span><?php echo e(Html::link('admin/tags/'.$tag->slug.'/edit', 'edit')); ?></span>
                    </td>
                    <td>
                        <span><?php echo e(Html::link('admin/tags/'.$tag->slug.'/destroy', 'delete')); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>