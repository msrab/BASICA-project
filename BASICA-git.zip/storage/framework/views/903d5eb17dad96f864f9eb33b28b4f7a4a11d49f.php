<!--
    resources/views/works/admin/create.blade.php
    view du formulaire de création d'un work
-->



<?php $__env->startSection('style'); ?>
<?php echo e(Html::style('//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
<!-- PAGE -->
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Ajouter un work </h2>
        <?php echo e(Form::open(array('url'=>'admin/works/store','enctype'=>'multipart/form-data'))); ?>

        <?php echo e(Form::token()); ?>


        <p>
            <?php echo e(Form::label('name','Nom')); ?>

            <?php echo e(Form::text('name', old('name'))); ?>

        </p>
        <?php if($errors->first('name')): ?>
        <span class="error"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('slug','Slug')); ?>

            <?php echo e(Form::text('slug', old('slug'))); ?>

        </p>
        <?php if($errors->first('slug')): ?>
        <span class="error"><?php echo e($errors->first('slug')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('client','Client')); ?>

            <?php echo e(Form::text('client', old('client'))); ?>

        </p>
        <?php if($errors->first('client')): ?>
        <span class="error"><?php echo e($errors->first('client')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('image','Image')); ?>

            <?php echo e(Form::file('image')); ?>

        </p>
        <?php if($errors->first('image')): ?>
        <span class="error"><?php echo e($errors->first('image')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('description','Description')); ?>

            <?php echo e(Form::textarea('description',old('description'))); ?>

        </p>
        <?php if($errors->first('description')): ?>
        <span class="error"><?php echo e($errors->first('description')); ?></span>
        <?php endif; ?>

        <p>
            
            
            
        </p>

        <p><?php echo e(Form::submit('Enregistrer')); ?></p>
        <?php echo e(Form::close()); ?>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo e(Html::script('https://code.jquery.com/ui/1.12.1/jquery-ui.js')); ?>

<script>
    $(function () {
        var availableTags = [
            "ActionScript",
            "AppleScript",
            "Asp",
            "BASIC",
            "C",
            "C++",
            "Clojure",
            "COBOL",
            "ColdFusion",
            "Erlang",
            "Fortran",
            "Groovy",
            "Haskell",
            "Java",
            "JavaScript",
            "Lisp",
            "Perl",
            "PHP",
            "Python",
            "Ruby",
            "Scala",
            "Scheme"
        ];
        $("#tags").autocomplete({
            source: availableTags
        });
    });


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>