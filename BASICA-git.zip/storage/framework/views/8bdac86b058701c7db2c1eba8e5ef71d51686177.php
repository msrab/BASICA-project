<!--
    resources/views/posts/admin/liste.blade.php
    view de la liste des posts
-->



<?php $__env->startSection('contenu'); ?>
<!-- PAGE -->
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Les posts </h2>
        <p><?php echo e(Html::link('admin/posts/create', 'Ajouter un post')); ?></p>
        <table>
            <thead>
                <tr>
                    <td>Titre</td>
                    <td>Categorie</td>
                    <td class='actions'></td>
                    <td class='actions'></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->category->name); ?></td>
                    <td>
                        <span><?php echo e(Html::link('admin/posts/'.$post->slug.'/edit', 'edit')); ?></span>
                    </td>
                    <td>
                        <span><?php echo e(Html::link('admin/posts/'.$post->slug.'/destroy', 'delete')); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>