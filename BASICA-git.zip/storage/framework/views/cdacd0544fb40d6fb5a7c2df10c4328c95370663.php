<!--
    resources/views/posts/posts.blade.php
    view de la page des posts
-->

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Blog Post Excerpt -->
<div class="col-sm-6">
    <div class="blog-post blog-single-post">
        <div class="single-post-title">
            <h2><?php echo e($post->title); ?></h2>
        </div>

        <div class="single-post-image">
            <img src="<?php echo e(Request::root().'/'.$post->image); ?>" alt="<?php echo e($post->title); ?>">
        </div>

        <div class="single-post-info">
            <i class="glyphicon glyphicon-time"></i><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d M, Y')); ?> <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
        </div>

        <div class="single-post-content">
            <p>
                <?php echo e(Str::words($post->text,70)); ?>

            </p>
            <a href="<?php echo e(URL::to('posts/'.$post->slug)); ?>" class="btn">Read more</a>
        </div>
    </div>
</div>
<!-- End Blog Post Excerpt -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Pagination -->

<?php  $i = 1  ?>
<div class="pagination-wrapper">
    <ul class="pagination pagination-sm">
        <li class=" <?php echo ($page == 1) ? 'disabled' : ''; ?> "><a href="<?php echo e(URL::to('posts')); ?>?page=<?php echo e($i); ?>">Previous</a></li>

        <?php for($i = 1; $i <= $pages; $i++): ?>
        <li class=" <?php echo ($i == $page) ? 'active' : ''; ?> ">
            <a href="<?php echo e(URL::to('posts')); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php  $i = 1  ?>
        <li class=" <?php echo ($page == $pages) ? 'disabled' : ''; ?> "><a href="<?php echo e(URL::to('posts')); ?>?page=<?php echo e($i+1); ?>">Next</a></li>
    </ul>

</div>