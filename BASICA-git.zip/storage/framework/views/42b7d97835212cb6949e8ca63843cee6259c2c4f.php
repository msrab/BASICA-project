<!--
    resources/views/articles/admin/edit.blade.php
    view du formulaire d'édition d'un article
-->



<?php $__env->startSection('contenu'); ?>
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Editer un article </h2>
        <?php echo e(Form::open(array('url'=>'admin/articles/update','enctype'=>'multipart/form-data'))); ?>

        <?php echo e(Form::token()); ?>


        <?php echo e(Form::hidden('id',$article->id)); ?>

        <p>
            <?php echo e(Form::label('title','Titre')); ?>

            <?php echo e(Form::text('title', isset($article->title) ? $article->title : old('title'))); ?>

        </p>
        <?php if($errors->first('title')): ?>
        <span class="error"><?php echo e($errors->first('title')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('slug','Slug')); ?>

            <?php echo e(Form::text('slug', isset($article->slug) ? $article->slug : old('slug'))); ?>

        </p>
        <?php if($errors->first('slug')): ?>
        <span class="error"><?php echo e($errors->first('slug')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('subtitle','Sous-titre')); ?>

            <?php echo e(Form::text('subtitle', isset($article->subtitle) ? $article->subtitle : old('subtitle'))); ?>

        </p>
        <?php if($errors->first('subtitle')): ?>
        <span class="error"><?php echo e($errors->first('subtitle')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('text','Texte')); ?>

            <?php echo e(Form::textarea('text', isset($article->text) ? $article->text : old('text'))); ?>

        </p>
        <p>
            <?php echo e(Form::label('image','Image')); ?>

            <?php echo e(Form::file('image')); ?>

        </p>
        <?php if($errors->first('image')): ?>
        <span class="error"><?php echo e($errors->first('image')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('slide','Afficher dans le slider')); ?>

            <?php echo Form::checkbox('slide',1, ($article->slide === 1) ? true : false); ?>

        </p>

        <p><?php echo e(Form::submit('Enregistrer')); ?></p>
        <?php echo e(Form::close()); ?>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>