<!--
    resources/views/home/portfolio.blade.php
    view de la liste des works récents
-->

<!-- Our Portfolio -->

<div class="section section-white">
    <div class="container">
        <div class="row">

            <div class="section-title">
                <h1>Our Recent Works</h1>
            </div>


            <ul class="grid cs-style-3">
                <?php echo $__env->make('works.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
        </div>
    </div>
</div>
<!-- Our Portfolio -->