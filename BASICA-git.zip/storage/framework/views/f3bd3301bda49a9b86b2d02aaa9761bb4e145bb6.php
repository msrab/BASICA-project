<!--
    resources/views/posts/list.blade.php
    view de la liste des posts
-->

<h4>Categories</h4>
<ul class="blog-categories">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(URL::to('categories/'.$category->slug)); ?>"><?php echo e($category->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>