<!--
    resources/views/works/show.blade.php
    view de la page de détails d'un work
-->



<?php $__env->startSection('contenu'); ?>
<!-- Page Title -->
<div class="section section-breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Product Details</h1>
            </div>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
        <div class="row">
            <!-- Product Image & Available Colors -->
            <div class="col-sm-6">
                <div class="product-image-large">
                    <img src="<?php echo e(Request::root().'/'.$work->image); ?>" alt="<?php echo e($work->name); ?>">
                </div>
                <div class="colors">
                    <span class="color-white"></span>
                    <span class="color-black"></span>
                    <span class="color-blue"></span>
                    <span class="color-orange"></span>
                    <span class="color-green"></span>
                </div>
            </div>
            <!-- End Product Image & Available Colors -->
            <!-- Product Summary & Options -->
            <div class="col-sm-6 product-details">
                <h2><?php echo e($work->name); ?></h2>
                <h3>Quick Overview</h3>
                <p><?php echo e(nl2br(e($work->description))); ?></p>
                <h3>Project Details</h3>
                <p><strong>Client: </strong><?php echo e($work->client); ?></p>
                <p><strong>Date: </strong><?php echo e(Carbon\Carbon::parse($work->created_at)->format('M,d Y')); ?></p>
                <p><strong>Tags: </strong>
                    <?php  $virgules = count($work->tags)-1  ?>
                    <?php $__currentLoopData = $work->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($tag->name); ?>

                    <?php if($virgules > 0): ?>
                    ,
                    <?php endif; ?>
                    <?php  $virgules--  ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
            <!-- End Product Summary & Options -->

        </div>
    </div>
</div>

<hr>

<?php echo $__env->make('works.similar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>