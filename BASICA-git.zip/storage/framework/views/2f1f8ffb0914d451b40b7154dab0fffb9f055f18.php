<!--
    resources/views/works/boucle.blade.php
    view de la liste des works
-->

<?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 col-sm-6">
    <figure>
        <img src="<?php echo e(Request::root().'/'.$work->image); ?>" alt="<?php echo e($work->name); ?>">
        <figcaption>
            <h3><?php echo e($work->name); ?></h3>
            <span><?php echo e($work->client); ?></span>
            <a href="<?php echo e(URL::to('works/'.$work->slug)); ?>">Take a look</a>
        </figcaption>
    </figure>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
