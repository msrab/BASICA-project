<!--
    resources/views/works/similar.blade.php
    view de la liste des works similaires
-->

<div class="section">
    <div class="container">
        <div class="row">

            <div class="section-title">
                <h1>Similar Works</h1>
            </div>

            <ul class="grid cs-style-2">
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('works.boucle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($works2 != null): ?>
                <?php $__currentLoopData = $works2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('works.boucle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>


        </div>
    </div>
</div>