<!--
    resources/views/posts/show.blade.php
    view de la page de détails d'un post
-->



<?php $__env->startSection('contenu'); ?>
<!-- Page Title -->
<div class="section section-breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Blog Post</h1>
            </div>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
        <div class="row">
            <!-- Blog Post -->
            <div class="col-sm-8">
                <div class="blog-post blog-single-post">
                    <div class="single-post-title">
                        <h2><?php echo e($post->title); ?></h2>
                    </div>

                    <div class="single-post-image">
                        <img src="<?php echo e(Request::root().'/'.$post->image); ?>" alt="<?php echo e($post->title); ?>">
                    </div>
                    <div class="single-post-info">
                        <i class="glyphicon glyphicon-time"></i><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d M, Y')); ?> <a href="#" title="Show Comments"><i class="glyphicon glyphicon-comment"></i>11</a>
                    </div>
                    <div class="single-post-content">
                        <h3><?php echo e($post->title); ?></h3>
                        <p><?php echo nl2br(e($post->text)); ?></p>
                    </div>
                </div>
            </div>
            <!-- End Blog Post -->
            <!-- Sidebar -->
            <div class="col-sm-4 blog-sidebar">

                <?php echo $__env->make('posts.recentPosts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('posts.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                

            </div>
            <!-- End Sidebar -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>