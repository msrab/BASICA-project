<!--
    resources/views/works/boucle.blade.php
    view de la liste des works
-->

<div class="col-md-3 col-sm-6">
    <figure>
        <img src="<?php echo e(Request::root().'/'.$work->image); ?>" alt="<?php echo e($work->name); ?>">
        <figcaption>
            <h3><?php echo e($work->name); ?></h3>
            <span><?php echo e($work->client); ?></span>
            <a href="<?php echo e(URL::to('works/'.$work->slug)); ?>">Take a look</a>
        </figcaption>
    </figure>
</div>