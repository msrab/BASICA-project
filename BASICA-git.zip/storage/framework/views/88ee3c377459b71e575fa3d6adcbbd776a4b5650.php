<?php $__env->startSection('contenu'); ?>
<div class="section section-breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Connexion</h1>
            </div>
        </div>
    </div>
</div>


<div class="section">
    <div class="container">
        <div class="row">
            <div class="container">
                <?php if(Session::has('alert_error')): ?>
                <div class="alert_error">
                    <?php echo e(Session::get('alert_error')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="container">
                <?php if(Session::has('alert_success')): ?>
                <div class="alert_success">
                    <?php echo e(Session::get('alert_success')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-12">
                <?php echo e(Form::open(array('url' => 'connexion'))); ?>

                <?php echo e(csrf_field()); ?>

                <h2>Connexion</h2>
                <p>
                    <?php echo e(Form::label('email', 'Email')); ?>

                    <?php echo e(Form::text('email', old('email'))); ?>

                </p>
                <?php if($errors->has('email')): ?>
                <p class = "error"><?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
                <p>
                    <?php echo e(Form::label('password', 'Mot de passe')); ?>

                    <?php echo e(Form::password('password')); ?>

                </p>
                <?php if($errors->has('password')): ?>
                <p class = "error"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>

                <p>
                    <?php echo e(Form::submit('Se connecter')); ?>

                </p>

                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>