<!--
    resources/views/works/admin/edit.blade.php
    view du formulaire d'édition d'un work
-->



<?php $__env->startSection('contenu'); ?>
<!-- PAGE -->
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Editer un work </h2>
        <?php echo e(Form::open(array('url'=>'admin/works/update','enctype'=>'multipart/form-data'))); ?>

        <?php echo e(Form::token()); ?>

        <?php echo e(Form::hidden('id',$work->id)); ?>

        
        <p>
            <?php echo e(Form::label('name','Nom')); ?>

            <?php echo e(Form::text('name', isset($work->name) ? $work->name : old('name'))); ?>

        </p>
        <?php if($errors->first('name')): ?>
        <span class="error"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
        
        <p>
            <?php echo e(Form::label('slug','Slug')); ?>

            <?php echo e(Form::text('slug', isset($work->slug) ? $work->slug : old('slug'))); ?>

        </p>
        <?php if($errors->first('slug')): ?>
        <span class="error"><?php echo e($errors->first('slug')); ?></span>
        <?php endif; ?>

        <p>
            <?php echo e(Form::label('client','Client')); ?>

            <?php echo e(Form::text('client', isset($work->client) ? $work->client : old('client'))); ?>

        </p>
        <?php if($errors->first('client')): ?>
        <span class="error"><?php echo e($errors->first('client')); ?></span>
        <?php endif; ?>
        
        <p>
            <?php echo e(Form::label('image','Image')); ?>

            <?php echo e(Form::file('image')); ?>

        </p>
        <?php if($errors->first('image')): ?>
        <span class="error"><?php echo e($errors->first('image')); ?></span>
        <?php endif; ?>
        <p>
            <?php echo e(Form::label('description','Description')); ?>

            <?php echo e(Form::textarea('description', isset($work->description) ? $work->description : old('description'))); ?>

        </p>
        <?php if($errors->first('description')): ?>
        <span class="error"><?php echo e($errors->first('description')); ?></span>
        <?php endif; ?>

        <p><?php echo e(Form::submit('Enregistrer')); ?></p>
        <?php echo e(Form::close()); ?>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>