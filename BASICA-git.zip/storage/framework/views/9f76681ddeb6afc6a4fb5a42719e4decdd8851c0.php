<!--
    resources/views/categories/admin/liste.blade.php
    view de la liste des catégories
-->



<?php $__env->startSection('contenu'); ?>
<!-- PAGE -->
<div id="page">
    <div id ="contenuPage" class="container clearfix">	
        <h2>Les categories </h2>
        <p><?php echo e(Html::link('admin/categories/create', 'Ajouter une categorie')); ?></p>
        <table>
            <thead>
                <tr>
                    <td>Categories</td>
                    <td class='actions'></td>
                    <td class='actions'></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->name); ?></td>
                    <td>
                        <span><?php echo e(Html::link('admin/categories/'.$category->slug.'/edit', 'edit')); ?></span>
                    </td>
                    <td>
                        <span><?php echo e(Html::link('admin/categories/'.$category->slug.'/destroy', 'delete')); ?></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>

        </table>
    </div> <!-- contenuPage -->
</div> <!-- #page -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>